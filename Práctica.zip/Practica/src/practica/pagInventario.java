package practica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Font;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SpinnerNumberModel;
import java.awt.Toolkit;

public class pagInventario extends JFrame {

	private JPanel contentPane;
	private JTable tbl_inventario;
	private JButton btn_volverPrincipal;
	private JButton btn_incluir;
	private JButton btn_eliminar;
	private JButton btn_actualizar;
	private JTextField txt_nombre;
	private JSpinner stxt_cantidad;
	private JSpinner stxt_precio;
	private JLabel lbl_nombre;
	private JLabel lbl_cantidad;
	private JLabel lbl_precio;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pagInventario frame = new pagInventario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Se inicia todo
	public pagInventario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(pagInventario.class.getResource("/imagenes/caja.png")));
		iniciarJFrame();
		iniciarJScrollPane();
		iniciarJTextField();
		iniciarJSpinner();
		iniciarJButton();
		iniciarJLabel();
		
		tbl_inventario.setDefaultEditor(Object.class, null); // Evita que se pueda editar los valores de la tabla directamente
		tbl_inventario.getTableHeader().setReorderingAllowed(false); // Evita que se pueda modificar el orden en la tabla
		DefaultTableModel model = (DefaultTableModel)tbl_inventario.getModel();
		model.addRow(new Object[] {"Pantalla", 15, 75});
		model.addRow(new Object[] {"Teclado", 5, 15});
		model.addRow(new Object[] {"Ratón", 20, 10});
	}
	
	// Agrupo todo por componentess
	// JFrame
	public void iniciarJFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Inventario");
		setBounds(100, 100, 750, 555);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 247, 251));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
	}
	
	// JScrollPane
	public void iniciarJScrollPane() {
		JScrollPane scrp_inventario = new JScrollPane();
		scrp_inventario.setFont(new Font("Segoe Print", Font.PLAIN, 10));
		scrp_inventario.setBounds(54, 37, 629, 241);
		contentPane.add(scrp_inventario);
		
		tbl_inventario = new JTable();
		tbl_inventario.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int fila = tbl_inventario.getSelectedRow();
				if (tbl_inventario.isRowSelected(fila)) {
					txt_nombre.setText(tbl_inventario.getValueAt(fila, 0).toString());
					stxt_cantidad.setValue(Integer.valueOf(tbl_inventario.getValueAt(fila, 1).toString()));
					stxt_precio.setValue(Double.valueOf(tbl_inventario.getValueAt(fila, 2).toString()));
				}
			}
		});
		tbl_inventario.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
			}
		});
		tbl_inventario.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre", "Cantidad", "Precio (unidad)"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, Double.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbl_inventario.getColumnModel().getColumn(0).setResizable(false);
		tbl_inventario.getColumnModel().getColumn(1).setResizable(false);
		tbl_inventario.getColumnModel().getColumn(2).setResizable(false);
		tbl_inventario.getColumnModel().getColumn(2).setPreferredWidth(85);
		scrp_inventario.setViewportView(tbl_inventario);
		tbl_inventario.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tbl_inventario.setFont(new Font("Arial", Font.PLAIN, 14));
	}
	
	// JButton
	public void iniciarJButton() {
		btn_volverPrincipal = new JButton("");
		btn_volverPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pagPrincipal principal = new pagPrincipal();
				principal.setVisible(true);
				dispose();
			}
		});
		btn_volverPrincipal.setIcon(new ImageIcon(pagInventario.class.getResource("/imagenes/flecha-curva.png")));
		btn_volverPrincipal.setVerticalTextPosition(SwingConstants.BOTTOM);
		btn_volverPrincipal.setVerticalAlignment(SwingConstants.TOP);
		btn_volverPrincipal.setOpaque(false);
		btn_volverPrincipal.setHorizontalTextPosition(SwingConstants.CENTER);
		btn_volverPrincipal.setFocusPainted(false);
		btn_volverPrincipal.setContentAreaFilled(false);
		btn_volverPrincipal.setBorderPainted(false);
		btn_volverPrincipal.setBorder(null);
		btn_volverPrincipal.setBounds(10, 432, 75, 73);
		contentPane.add(btn_volverPrincipal);
		
		btn_incluir = new JButton("Incluir");
		btn_incluir.setBackground(new Color(240, 240, 240));
		btn_incluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Cuando se pulsa el boton "Incluir" se incluye el objeto que hayamos introducido en la tabla
				try {
					DefaultTableModel model = (DefaultTableModel)tbl_inventario.getModel();
					int confirmarCrear;
					if (!txt_nombre.getText().equals("")) {
							confirmarCrear = JOptionPane.showConfirmDialog(null,
									"¿Quiere incluir [" + txt_nombre.getText() + ", " + stxt_cantidad.getValue() + ", " + stxt_precio.getValue() + "]?",
									"Incluir", JOptionPane.YES_NO_OPTION);
						if (confirmarCrear == JOptionPane.YES_OPTION) {
							model.addRow(new Object[] {txt_nombre.getText(), stxt_cantidad.getValue(), stxt_precio.getValue()});
						}
					}
				}catch (Exception e1) {
					System.out.println("ERROR: Boton incluir");
				}
			}
		});
		btn_incluir.setBounds(454, 401, 112, 26);
		contentPane.add(btn_incluir);
		
		btn_eliminar = new JButton("Eliminar");
		btn_eliminar.setBackground(new Color(240, 240, 240));
		btn_eliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Elimina de la tabla el objeto seleccionado
					int fila = tbl_inventario.getSelectedRow();
					DefaultTableModel model = (DefaultTableModel)tbl_inventario.getModel();
					if (fila >= 0) {
						int confirmarEliminar = JOptionPane.showConfirmDialog(null,
								"¿Quiere eliminar [" + txt_nombre.getText() + ", " + stxt_cantidad.getValue() + ", " + stxt_precio.getValue() + "]?",
								"Eliminar", JOptionPane.YES_NO_OPTION);
						if (confirmarEliminar == JOptionPane.YES_OPTION) {
							model.removeRow(fila);
						}
					}else {
						JOptionPane.showMessageDialog(null, "Por favor, seleccione un objeto",
								"Objeto no seleccionado", JOptionPane.ERROR_MESSAGE);
					}
				}catch (Exception e1) {
					System.out.println("ERROR: Boton eliminar");
				}
			}
		});
		btn_eliminar.setBounds(325, 401, 112, 26);
		contentPane.add(btn_eliminar);
		
		btn_actualizar = new JButton("Actualizar");
		btn_actualizar.setBackground(new Color(240, 240, 240));
		btn_actualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Actualizar en la tabla el objeto seleccionado por el objeto introducido
					int fila = tbl_inventario.getSelectedRow();
					DefaultTableModel model = (DefaultTableModel)tbl_inventario.getModel();
					if (fila >= 0) {
						int confirmarEliminar = JOptionPane.showConfirmDialog(null,
								"¿Quiere actualizar [" + tbl_inventario.getValueAt(fila, 0).toString() + ", " + tbl_inventario.getValueAt(fila, 1) + ", " + Double.valueOf(tbl_inventario.getValueAt(fila, 2).toString()) + "] por [" + txt_nombre.getText() + ", " + stxt_cantidad.getValue() + ", " + stxt_precio.getValue() + "]?",
								"Eliminar", JOptionPane.YES_NO_OPTION);
						if (confirmarEliminar == JOptionPane.YES_OPTION) {
							model.setValueAt(txt_nombre.getText(), fila, 0);
							model.setValueAt(stxt_cantidad.getValue(), fila, 1);
							model.setValueAt(stxt_precio.getValue(), fila, 2);
						}
					}else {
						JOptionPane.showMessageDialog(null, "Por favor, seleccione un objeto",
								"Objeto no seleccionado", JOptionPane.ERROR_MESSAGE);
					}
				}catch (Exception e1) {
					System.out.println("ERROR: Boton actualizar");
				}
			}
		});
		btn_actualizar.setBounds(196, 401, 112, 26);
		contentPane.add(btn_actualizar);
	}
	
	// JTextField
	public void iniciarJTextField() {
		txt_nombre = new JTextField();
		txt_nombre.setBounds(196, 364, 112, 26);
		contentPane.add(txt_nombre);
		txt_nombre.setColumns(10);
	}
	
	// JSpinner
	public void iniciarJSpinner() {
		stxt_cantidad = new JSpinner();
		stxt_cantidad.setModel(new SpinnerNumberModel(0, null, 999, 1));
		stxt_cantidad.setBounds(325, 364, 112, 26);
		contentPane.add(stxt_cantidad);
		
		stxt_precio = new JSpinner();
		stxt_precio.setModel(new SpinnerNumberModel(0.0, null, 9999.0, 1.0));
		stxt_precio.setBounds(454, 364, 112, 26);
		contentPane.add(stxt_precio);
	}
	
	// JLabel
	public void iniciarJLabel() {
		lbl_nombre = new JLabel("Nombre:");
		lbl_nombre.setBounds(196, 345, 68, 14);
		contentPane.add(lbl_nombre);
		
		lbl_cantidad = new JLabel("Cantidad:");
		lbl_cantidad.setBounds(325, 345, 68, 14);
		contentPane.add(lbl_cantidad);
		
		lbl_precio = new JLabel("Precio:");
		lbl_precio.setBounds(454, 345, 68, 14);
		contentPane.add(lbl_precio);
	}
}
