package practica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class pagPrincipal extends JFrame {

	private JPanel contentPane;
	private JButton btn_irInventario;
	private JButton btn_usuarios;
	private JLabel lbl_bienvenido;
	JMenuBar mb_menu;
	JMenu m_ajustes;
	JMenuItem mi_cambiarNombre;
	JMenu m_inventario;
	JMenuItem mi_comprobarInventario;
	
	private static String nombreUsuario;
	private JMenuItem mi_salir;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pagPrincipal frame = new pagPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	// Se inicia todo
	public pagPrincipal() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(pagPrincipal.class.getResource("/imagenes/casa.png")));
		iniciarJFrame();
		iniciarJLabel();
		iniciarJButton();
	}
	
	
	// Agrupo todo por componentes
	// JFrame
	public void iniciarJFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Pagina principal");
		setBounds(100, 100, 750, 555);
		
		mb_menu = new JMenuBar();
		setJMenuBar(mb_menu);
		
		m_inventario = new JMenu("Inventario");
		mb_menu.add(m_inventario);
		
		mi_comprobarInventario = new JMenuItem("Comprobar inventario");
		mi_comprobarInventario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pagInventario inventario = new pagInventario();
				inventario.setVisible(true);
				dispose();
			}
		});
		m_inventario.add(mi_comprobarInventario);
		
		m_ajustes = new JMenu("Ajustes");
		mb_menu.add(m_ajustes);
		
		mi_cambiarNombre = new JMenuItem("Cambiar nombre");
		mi_cambiarNombre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actualizarNombre();
			}
		});
		m_ajustes.add(mi_cambiarNombre);
		
		mi_salir = new JMenuItem("Salir");
		mi_salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		m_ajustes.add(mi_salir);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 247, 251));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
	}
	
	// JLabel
	public void iniciarJLabel() {
		nombreUsuario = "Usuario";
		lbl_bienvenido = new JLabel("¡Bienvenido " + nombreUsuario + "!");
		lbl_bienvenido.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_bienvenido.setFont(new Font("Segoe Print", Font.PLAIN, 40));
		lbl_bienvenido.setBounds(10, 11, 714, 109);
		contentPane.add(lbl_bienvenido);
	}
	
	// Botones
	public void iniciarJButton() {
		btn_irInventario = new JButton("Comprobar inventario");
		btn_irInventario.setFont(new Font("Serif", Font.BOLD, 17));
		btn_irInventario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pagInventario inventario = new pagInventario();
				inventario.setVisible(true);
				dispose();
			}
		});
		btn_irInventario.setIcon(new ImageIcon(pagPrincipal.class.getResource("/imagenes/caja.png")));
		btn_irInventario.setBounds(403, 279, 272, 115);
		contentPane.add(btn_irInventario);
		
		btn_usuarios = new JButton("Cambiar nombre");
		btn_usuarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actualizarNombre();
			}
		});
		btn_usuarios.setIcon(new ImageIcon(pagPrincipal.class.getResource("/imagenes/usuario.png")));
		btn_usuarios.setFont(new Font("Serif", Font.BOLD, 17));
		btn_usuarios.setBounds(64, 279, 272, 115);
		contentPane.add(btn_usuarios);
	}
	
	// Actualiza el nombre mostrado en lbl_bienvenida
	public void actualizarNombre() {
		String nuevoNombreUsuario = JOptionPane.showInputDialog(null, "Introduzca el nuevo nombre de usuario:");
		if (nuevoNombreUsuario != null) {
			nombreUsuario = nuevoNombreUsuario;
		}
		lbl_bienvenido.setText("¡Bienvenido " + nombreUsuario + "!");
	}
}